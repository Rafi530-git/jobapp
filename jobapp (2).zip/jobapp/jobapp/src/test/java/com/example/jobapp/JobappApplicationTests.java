package com.example.jobapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobappApplicationTests {

	@Test
	void contextLoads() {
	}

}
