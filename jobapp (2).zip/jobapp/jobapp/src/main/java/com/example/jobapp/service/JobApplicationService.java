package com.example.jobapp.service;

import com.example.jobapp.model.JobApplication;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class JobApplicationService {
    private final List<JobApplication> applications = new ArrayList<>();
    private Long idCounter = 1L;

    // Upload a job application
    public JobApplication uploadApplication(String applicantName, MultipartFile file) {
        JobApplication application = new JobApplication(
                idCounter++,
                applicantName,
                file.getOriginalFilename(),
                file.getContentType(),
                LocalDate.now()
        );
        applications.add(application);
        return application;
    }

    // List all job applications
    public List<JobApplication> getAllApplications() {
        return new ArrayList<>(applications);
    }

    // Delete a job application by ID
    public boolean deleteApplication(Long id) {
        return applications.removeIf(app -> app.getId().equals(id));
    }
}
