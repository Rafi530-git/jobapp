package com.example.jobapp.model;

import java.time.LocalDate;

public class JobApplication {
    private Long id;
    private String applicantName;
    private String fileName;
    private String fileType;
    private LocalDate uploadDate;

    // Constructor
    public JobApplication(Long id, String applicantName, String fileName, String fileType, LocalDate uploadDate) {
        this.id = id;
        this.applicantName = applicantName;
        this.fileName = fileName;
        this.fileType = fileType;
        this.uploadDate = uploadDate;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getApplicantName() {
        return applicantName;
    }

    public void setApplicantName(String applicantName) {
        this.applicantName = applicantName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public LocalDate getUploadDate() {
        return uploadDate;
    }

    public void setUploadDate(LocalDate uploadDate) {
        this.uploadDate = uploadDate;
    }
}
